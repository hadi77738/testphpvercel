<?php
// Mengatur header untuk memberitahu client bahwa response-nya adalah JSON
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // Membuka akses untuk semua (untuk development)

// Memasukkan file koneksi database
require_once '../includes/db.php';

// Inisialisasi array response
$response = array();

// Cek apakah parameter 'keyword' ada di URL
if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // Menyiapkan keyword untuk query LIKE agar bisa mencari bagian kata
    $search_keyword = "%" . $keyword . "%";

    // Query untuk mencari idiom berdasarkan keyword di kolom 'idiom' atau 'meaning_id'
    // Menggunakan prepared statement untuk mencegah SQL Injection
    $sql = "SELECT * FROM idioms WHERE idiom LIKE ? OR meaning_id LIKE ?";
    
    $stmt = $conn->prepare($sql);
    
    // Bind parameter ke statement
    $stmt->bind_param("ss", $search_keyword, $search_keyword);

    // Eksekusi query
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $idioms = array();

        if ($result->num_rows > 0) {
            // Mengambil semua baris hasil dan memasukkannya ke array
            while ($row = $result->fetch_assoc()) {
                $idioms[] = $row;
            }
            $response['status'] = 'success';
            $response['data'] = $idioms;
        } else {
            // Jika tidak ada data yang ditemukan
            $response['status'] = 'success';
            $response['data'] = []; // Kirim array kosong
            $response['message'] = 'Tidak ada idiom yang cocok ditemukan.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Eksekusi query gagal: ' . $stmt->error;
    }
    
    // Menutup statement
    $stmt->close();

} else {
    // Jika parameter keyword tidak diberikan
    $response['status'] = 'error';
    $response['message'] = "Parameter 'keyword' tidak ditemukan.";
}

// Menutup koneksi database
$conn->close();

// Mengubah array response menjadi format JSON dan menampilkannya
echo json_encode($response);
